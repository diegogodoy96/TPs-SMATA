//TP 3 Diego Martín Godoy
//corrección 07/07/2025

//imprimir en caja resultado
//https://crios2020.github.io/calculadora

function calcular(){
	peso=document.getElementById("peso")
	altura=document.getElementById("altura")
	imc=calcularImc(peso,altura)
	estado=obtenerEstado(imc)
	document.getElementById("resultadoImc").value=imc
	document.getElementById("resultadoEst").value=estado
}

function calcularImc(peso,altura){
	nro1=parseFloat(document.getElementById("peso").value)
	nro2=parseFloat(document.getElementById("altura").value)
	imc=nro1 / (nro2 ** 2)
	return imc.toFixed(2)
}

function obtenerEstado(imc) {
    estado=""
        if (imc <= 15){
            estado = "Delgadez muy severa"
        }
        else if (imc >= 15.1 && imc <= 15.9){
            estado = "Delgadez severa"
        }
        else if (imc >= 16 && imc <= 18.4){
            estado = "Delgadez"
        }
        else if (imc >= 18.5 && imc <= 24.9){ //entre 24.91 y 25 no tira estado
            estado = "Saludable"
        }
        else if (imc >= 25 && imc <= 29.9){
            estado = "Sobrepeso"
        }
        else if (imc >= 30 && imc <= 34.9){
            estado = "Obesidad moderada"
        }
        else if (imc >= 35 && imc <= 39.9){
            estado = "Obesidad severa"
        }
        else if (imc >= 40){
            estado = "Obesidad mórbida"
        }
	return estado
}
