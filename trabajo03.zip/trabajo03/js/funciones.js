//imprimir en caja resultado
//https://crios2020.github.io/calculadora


function calcularIMC(){
    nro1=parseFloat(document.getElementById("number1").value)
    nro2=parseFloat(document.getElementById("number2").value)
    IMC=nro1 / (nro2 ** 2)
    document.getElementById("resultadoImc").value=(IMC.toFixed(2))
}

function obtenerEstado() {
    estado=""
        if (IMC <= 15){
            estado = "Delgadez muy severa"
        }
        else if (IMC >= 15.1 && IMC <= 15.9){
            estado = "Delgadez severa"
        }
        else if (IMC >= 16 && IMC <= 18.4){
            estado = "Delgadez"
        }
        else if (IMC >= 18.5 && IMC <= 24.9){ //entre 24.91 y 25 no tira estado
            estado = "Saludable"
        }
        else if (IMC >= 25 && IMC <= 29.9){
            estado = "Sobrepeso"
        }
        else if (IMC >= 30 && IMC <= 34.9){
            estado = "Obesidad moderada"
        }
        else if (IMC >= 35 && IMC <= 39.9){
            estado = "Obesidad severa"
        }
        else if (IMC >= 40){
            estado = "Obesidad mórbida"
        }
    document.getElementById("resultadoEst").value=estado
}
