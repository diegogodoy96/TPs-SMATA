//Trabajo 2
//Entrega para el 15/06/2025

//1 - Crear la función calcularMasaCorporal, en esta función ingresa como parámetro el peso y la altura,
//    y devuelve el indice de masa corporal.

function calcularMasaCorporal() {
    //Determinar cuales son los datos de entrada para el imc.
    peso = prompt("Ingrese su peso: ")
    altura = prompt("Ingrese su altura: ")

    //Informar datos ingresados
    document.writeln("Peso: " + peso +"kg"+"<br>")
    document.writeln("Altura: " + altura +"m"+"<br>")

    //Calcular el IMC.
    IMC = peso / (altura ** 2)
    return IMC
}

//2 - Crear la función obtenerEstado, ingresa como parámetro el IMC y devuelve un String con el estado
//    'Normal','SobrePeso','Obesidad' etc.

function obtenerEstado() {
    //Calcular estado (Delgadez - Normal - Obesidad etc)
    estado=""
        if (IMC <= 15){
            estado = "Delgadez muy severa"
        }
        else if (IMC >= 15.1 && IMC <= 15.9){
            estado = "Delgadez severa"
        }
        else if (IMC >= 16 && IMC <= 18.4){
            estado = "Delgadez"
        }
        else if (IMC >= 18.5 && IMC <= 24.9){
            estado = "Saludable"
        }
        else if (IMC >= 25 && IMC <= 29.9){
            estado = "Sobrepeso"
        }
        else if (IMC >= 30 && IMC <= 34.9){
            estado = "Obesidad moderada"
        }
        else if (IMC >= 35 && IMC <= 39.9){
            estado = "Obesidad severa"
        }
        else if (IMC >= 40){
            estado = "Obesidad mórbida"
        }
        return estado
}