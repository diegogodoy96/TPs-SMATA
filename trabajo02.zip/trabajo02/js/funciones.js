//Trabajo 2
//Entrega para el 15/06/2025

//1 - Crear la función calcularMasaCorporal, en esta función ingresa como parámetro el peso y la altura,
//    y devuelve el indice de masa corporal.

function calcularMasaCorporal() {
    //Determinar cuales son los datos de entrada para el imc.
    peso = prompt("Ingrese su peso: ")
    altura = prompt("Ingrese su altura: ")

    //Informar datos ingresados
    document.writeln("Peso: " + peso +"kg"+"<br>")
    document.writeln("Altura: " + altura +"m"+"<br>")

    //Calcular el IMC.
    IMC = peso / (altura ** 2)
    return IMC
}

//2 - Crear la función obtenerEstado, ingresa como parámetro el IMC y devuelve un String con el estado
//    'Normal','SobrePeso','Obesidad' etc.

function obtenerEstado() {
    //Calcular estado (Delgadez - Normal - Obesidad etc)
    estado = ""
    if (IMC < 18.4) {
        estado = "Delgado"
    }
    else if (IMC >= 18.5 && IMC <= 24.9) {
        estado = "Saludable"
    }
    else if (IMC > 25) {
        estado = "Obeso"
    }
    return estado
}