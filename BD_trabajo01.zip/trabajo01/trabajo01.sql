-- Base de Datos | Turno noche
-- Diego Martín Godoy | Trabajo 01

-- Crear la base de datos del diagrama Reservas.png
drop database if exists hotel;
create database hotel;
show databases;
use hotel;

-- Ingresar registros de prueba.

CREATE TABLE habitaciones
	(
		habitacion_numero INT PRIMARY KEY,
        precio_por_noche DECIMAL(6,2),
        piso INT,
        max_personas TINYINT,
        tiene_cama_bebe TINYINT,
        tiene_ducha TINYINT,
        tiene_bano TINYINT,
        tiene_balcon TINYINT
	);
    
drop table huespedes;
CREATE TABLE huespedes
	(
		huesped_id int PRIMARY KEY auto_increment,
        nombres VARCHAR(45),
        apellidos VARCHAR(45),
        telefono DOUBLE,
        correo VARCHAR(45),
        direccion VARCHAR(45),
        ciudad VARCHAR(45),
        pais VARCHAR(45)
	);

drop table reservas;
CREATE TABLE  reservas
   (
      reservas_id int PRIMARY KEY auto_increment,
      inicio_fecha DATETIME,
      fin_fecha DATETIME,
      habitacion INT,
      huesped INT,
      
      
      FOREIGN KEY (habitacion) REFERENCES habitaciones(habitacion_numero),
      FOREIGN KEY (huesped) REFERENCES huespedes(huesped_id)
   );
   
select * from habitaciones;
select * from reservas;
select * from huespedes;

insert into habitaciones (habitacion_numero, precio_por_noche, piso, max_personas, tiene_cama_bebe, tiene_ducha, tiene_bano, tiene_balcon) values (01,1000,0,4,1,1,1,0);
insert into habitaciones (habitacion_numero, precio_por_noche, piso, max_personas, tiene_cama_bebe, tiene_ducha, tiene_bano, tiene_balcon) values (02,1000,0,4,1,1,1,0);
insert into habitaciones (habitacion_numero, precio_por_noche, piso, max_personas, tiene_cama_bebe, tiene_ducha, tiene_bano, tiene_balcon) values (03,1000,0,2,1,1,1,0);
insert into habitaciones (habitacion_numero, precio_por_noche, piso, max_personas, tiene_cama_bebe, tiene_ducha, tiene_bano, tiene_balcon) values (04,1000,0,2,1,1,1,0);
insert into habitaciones (habitacion_numero, precio_por_noche, piso, max_personas, tiene_cama_bebe, tiene_ducha, tiene_bano, tiene_balcon) values (05,1000,0,2,0,1,1,0);
insert into habitaciones (habitacion_numero, precio_por_noche, piso, max_personas, tiene_cama_bebe, tiene_ducha, tiene_bano, tiene_balcon) values (06,3000,1,3,1,1,1,0);
insert into habitaciones (habitacion_numero, precio_por_noche, piso, max_personas, tiene_cama_bebe, tiene_ducha, tiene_bano, tiene_balcon) values (07,3000,1,4,1,1,1,0);
insert into habitaciones (habitacion_numero, precio_por_noche, piso, max_personas, tiene_cama_bebe, tiene_ducha, tiene_bano, tiene_balcon) values (08,3000,1,5,0,1,1,1);
insert into habitaciones (habitacion_numero, precio_por_noche, piso, max_personas, tiene_cama_bebe, tiene_ducha, tiene_bano, tiene_balcon) values (09,3000,1,5,0,1,1,1);
insert into habitaciones (habitacion_numero, precio_por_noche, piso, max_personas, tiene_cama_bebe, tiene_ducha, tiene_bano, tiene_balcon) values (10,3000,1,4,0,1,1,1);
insert into habitaciones (habitacion_numero, precio_por_noche, piso, max_personas, tiene_cama_bebe, tiene_ducha, tiene_bano, tiene_balcon) values (11,6000,2,3,0,1,1,1);
insert into habitaciones (habitacion_numero, precio_por_noche, piso, max_personas, tiene_cama_bebe, tiene_ducha, tiene_bano, tiene_balcon) values (12,6000,2,4,0,1,1,1);
insert into habitaciones (habitacion_numero, precio_por_noche, piso, max_personas, tiene_cama_bebe, tiene_ducha, tiene_bano, tiene_balcon) values (13,6000,2,5,0,1,1,1);
insert into habitaciones (habitacion_numero, precio_por_noche, piso, max_personas, tiene_cama_bebe, tiene_ducha, tiene_bano, tiene_balcon) values (14,6000,2,5,0,1,1,1);
insert into habitaciones (habitacion_numero, precio_por_noche, piso, max_personas, tiene_cama_bebe, tiene_ducha, tiene_bano, tiene_balcon) values (15,6000,2,4,0,1,1,1);

select * from huespedes;

insert into huespedes (nombres,apellidos,telefono,correo,direccion,ciudad,pais) values ('Jorge','Jordan',1155849271,'jsanchez@hotmail.com','Av.Medrano 184','Buenos Aires','Argentina');
insert into huespedes (nombres,apellidos,telefono,correo,direccion,ciudad,pais) values ('Armando','Barreda',1199228833,'abarreda@hotmail.com','Av.Rivadavia 932','Buenos Aires','Argentina');
insert into huespedes (nombres,apellidos,telefono,correo,direccion,ciudad,pais) values ('Michael','Smith',1145835932,'msmith@hotmail.com','Av.Callao 348','Buenos Aires','Argentina');
insert into huespedes (nombres,apellidos,telefono,correo,direccion,ciudad,pais) values ('Matías','Perez',1147832948,'mperez@hotmail.com','Av.Cordoba 837','Buenos Aires','Argentina');
insert into huespedes (nombres,apellidos,telefono,correo,direccion,ciudad,pais) values ('Fernando','Fernandez',1194382748,'ffernandez@hotmail.com','Av.La Plata 374','Buenos Aires','Argentina');
insert into huespedes (nombres,apellidos,telefono,correo,direccion,ciudad,pais) values ('Arnold','Schwarzzeneger',118374892,'terminator@skynet.com','Av. Libertador 928','Arizona','United States');
insert into huespedes (nombres,apellidos,telefono,correo,direccion,ciudad,pais) values ('Guillermo','Franccela',1174663728,'gfranccela@hotmail.com','Av. Gallardo 203','Buenos Aires','Argentina');
insert into huespedes (nombres,apellidos,telefono,correo,direccion,ciudad,pais) values ('Will','Smith',1183442948,'wsmith@hotmail.com','Av.Corrientes 234','Buenos Aires','Argentina');
insert into huespedes (nombres,apellidos,telefono,correo,direccion,ciudad,pais) values ('Sam','Neil',1584392875,'sneil@hotmail.com','Av.Nublar 1993','Hawaii','United States');
insert into huespedes (nombres,apellidos,telefono,correo,direccion,ciudad,pais) values ('Christopher','Nolan',1137483748,'cnolan@outlook.com','Av. 2','Londres','United Kingdom');

select * from reservas;

insert into reservas (inicio_fecha, fin_fecha, habitacion, huesped) values ('2025/01/18','2025/02/18',02,2);
insert into reservas (inicio_fecha, fin_fecha, habitacion, huesped) values ('2025/01/18','2025/02/15',03,3);
insert into reservas (inicio_fecha, fin_fecha, habitacion, huesped) values ('2025/01/01','2025/01/31',04,4);
insert into reservas (inicio_fecha, fin_fecha, habitacion, huesped) values ('2025/02/01','2025/02/28',05,5);
insert into reservas (inicio_fecha, fin_fecha, habitacion, huesped) values ('2025/11/15','2025/12/15',06,8);
insert into reservas (inicio_fecha, fin_fecha, habitacion, huesped) values ('2025/08/01','2025/08/15',07,9);
insert into reservas (inicio_fecha, fin_fecha, habitacion, huesped) values ('2025/03/01','2025/03/15',08,10);
insert into reservas (inicio_fecha, fin_fecha, habitacion, huesped) values ('2025/04/01','2025/04/15',08,10);
insert into reservas (inicio_fecha, fin_fecha, habitacion, huesped) values ('2025/03/01','2025/03/15',08,10);
insert into reservas (inicio_fecha, fin_fecha, habitacion, huesped) values ('2025/03/01','2025/03/15',08,10);

UPDATE  reservas
set	fin_fecha = '2025/06/15'
where reservas_id = 1;

-- Realizar consultas de prueba.

select * from habitaciones;
select * from reservas;
select * from huespedes;

-- Informar qué habitación reservó cada huesped y id de reserva

select hu.huesped_id, hu.nombres, hu.apellidos, ha.habitacion_numero, r.reservas_id
    from huespedes hu join reservas r on hu.huesped_id=r.reservas_id
    join habitaciones ha on ha.habitacion_numero=r.reservas_id;

-- Informar qué habitación reservó 'Will Smith'

select hu.huesped_id, hu.nombres, hu.apellidos, ha.habitacion_numero, r.reservas_id
    from huespedes hu join reservas r on hu.huesped_id=r.reservas_id
    join habitaciones ha on ha.habitacion_numero=r.reservas_id
    where hu.nombres='Will' and hu.apellidos='Smith';

-- Informar la cantidad de habitaciones reservadas

select hu.huesped_id, hu.nombres, hu.apellidos, ha.habitacion_numero, r.reservas_id, sum(ha.habitacion_numero) cantidad_de_habitaciones
    from huespedes hu join reservas r on hu.huesped_id=r.reservas_id
    join habitaciones ha on ha.habitacion_numero=r.reservas_id;
